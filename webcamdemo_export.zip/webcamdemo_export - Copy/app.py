#  webcamdemo_export

import sys
sys.path.insert(0,"db/")
from db.dbhelper import *
import os

from flask import Flask,render_template,request,redirect,url_for, flash

upload_folder="static/images"
app = Flask(__name__)
app.config['UPLOAD_FOLDER']=upload_folder
app.secret_key = "flash"


@app.route("/savestudent",methods=['POST','GET'])
def savestudent()->None:
    if request.method=="POST":
        file:any = request.files['webcam']
        idno:str = request.args.get('idno')
        lastname:str = request.args.get('lastname')
        firstname:str = request.args.get('firstname')
        course:str = request.args.get('course')
        level:str = request.args.get('level')
        filename = upload_folder+"/"+idno+".png"
        file.save(filename)
        
        ok:bool = addrecord('students',idno=idno,lastname=lastname,firstname=firstname,course=course,level=level,image=filename)
        message:str = "STUDENT SAVE" if ok else "ERROR SAVING STUDENT"
        print(message)
        
    return redirect(url_for(index))


@app.route("/")
def index()->None:
    students:list = getall('students')
    return render_template('index.html',studentlist=students)
    
    
    
    
@app.route("/updatestudent", methods=["POST"])
def updatestudent():
    idno = request.form['idno']
    lastname = request.form['lastname']
    firstname = request.form['firstname']
    course = request.form['course']
    level = request.form['level']

    ok = updaterecord('students', idno=idno, lastname=lastname, firstname=firstname, course=course, level=level)
    if ok:
        flash("Student record updated successfully!", "success")
    else:
        flash("Something went wrong. Record not updated.", "error")

    return redirect(url_for("index"))
    
    
@app.route("/deletestudent")
def deletestudent()->None:
    idno:int = request.args.get('idno')
    
    # Get the student record to find the image path
    student = getone('students', idno=idno)  # You may need a function getone to fetch a single record
    
    if student and 'image' in student:
        image_path = student['image']
        if os.path.exists(image_path):
            os.remove(image_path)  # Delete the image file
    
    
    ok:bool = deleterecord('students', idno=idno)
    if ok == True:
        flash("Student record deleted successfully!", "success")
    else:
        flash("Something went wrong. Student not deleted.", "error")

    return redirect(url_for("index"))




   
    
    
if __name__=="__main__":
    app.run(debug=True)